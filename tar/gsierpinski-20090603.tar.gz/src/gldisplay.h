/*
 *      gldisplay.h
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#ifndef __gldisplay_h_
#define __gldisplay_h_


#include <GL/gl.h>
#include <GL/glu.h>
#include "data_structures_init.h"
  

#define GLTRANSLATE_MIN     -10.0
#define GLTRANSLATE_MAX      10.0
#define ANGLE_MAX           360.0
#define ANGLE_MIN          -360.0

#define FIXED_Z              -4.0


#define GLDISPLAY_LISTS       1

#define VIEW_SCALE_MAX 2.0
#define VIEW_SCALE_MIN 0.5

#define DIG_2_RAD (G_PI / 180.0)
#define RAD_2_DIG (180.0 / G_PI)

#define ANIMATE_THRESHOLD 25.0
 

 
typedef enum {

    DISPLAY_DATA,
    DISPLAY_STATISTICS,
    DISPLAY_COMBINED,
  
} t_display_datatype_enum;

 
  
//~ --------------------------------------------------------------------------------------------------------------------
//~ *                                gldisplay_display_data
//~ --------------------------------------------------------------------------------------------------------------------
 
typedef struct _gldisplay_display_data gldisplay_display_data;

struct _gldisplay_display_data  {


    GLuint gldisplay [GLDISPLAY_LISTS];

    gboolean animate;
     
    gfloat view_quat_diff [4];
    gfloat view_quat [4];
    gfloat view_scale;
    gfloat begin_x;
    gfloat begin_y; 
    gfloat dx;
    gfloat dy;
      
    GLfloat *sierpinski_color;
/*
    GLfloat *sierpinski_color_fade;
*/
 
    GLuint   sierpinski_depth;
 
 
    // all display parameters (gldisplay required!) shall be stored here

}; 

 

//~ --------------------------------------------------------------------------------------------------------------------
//~ *                         gldisplay_scene
//~ --------------------------------------------------------------------------------------------------------------------

typedef struct _gldisplay_scene gldisplay_scene;

struct _gldisplay_scene {

    GLdouble dimensions [4];
    GLdouble Z_layer;

    // here may be also FIXED_Z

    GLdouble glupersp [4];
    GLfloat color [4];
    GLfloat clearcolor [4];
    GLfloat backgroundcolor [4];

    GLdouble gltranslate [3];
    GLdouble glrotate [4];

};
 







void gldisplay_update_display_data (gldisplay_display_data *destination,
                                    current_data *source_param);


void gldisplay_realize_main_gldisplay       (GtkWidget *widget, gpointer data);
void gldisplay_expose_main_gldisplay        (GdkGLDrawable *gldrawable, gpointer data);

 


#endif // __gldisplay_h_
