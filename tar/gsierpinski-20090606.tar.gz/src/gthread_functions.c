/*
 *      gthread_functions.c
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <glib.h>
#include <GL/gl.h>
#include <GL/glu.h>


#include "data_structures_init.h"

/*
#include "gtk_callbacks.h"
*/

/*
#include "glarea_callbacks.h"
#include "gtk_frontend_gl_widgets.h"
*/
 
  
//~ ----------------------------------------------------------------------------
//~ threads definitions and vars
//~ ----------------------------------------------------------------------------
 
gulong dbg_sleep = 10000 * 1000; // 10s
gulong move_sleep = 50000;
 
 
gpointer *gthread_dbg (gpointer data) {

    #ifdef DEBUG_THREADS
        DEBUG_LOG_FLOW (DEBUG_THREADS, "debug thread attached. ", " ")
    #endif

    while (TRUE) {

        if (gthreads->debug_thread_runs) {

        displaydata->frames_per_second = (gfloat) displaydata->frame_counter / 10.0;
        displaydata->frame_counter = 0;
  
        // in debug thread there shall be no #ifdef for logging - as debug thread may be attached or not
        DEBUG_LOG_FLOW      (DEBUG_THREADS, "gthread_dbg", "dumping variable values:")
        DEBUG_LOG_INTEGER   (DEBUG_THREADS, " ", "displaydata->animate", displaydata->animate)
        DEBUG_LOG_FLOAT_ARRAY (DEBUG_THREADS, " ", "displaydata->view_quat_diff [4] = ", displaydata->view_quat_diff, 4)
        DEBUG_LOG_FLOAT_ARRAY (DEBUG_THREADS, " ", "displaydata->view_quat [4] = ", displaydata->view_quat, 4)
        DEBUG_LOG_FLOAT     (DEBUG_THREADS, " ", "displaydata->view_scale", displaydata->view_scale)
        DEBUG_LOG_FLOAT     (DEBUG_THREADS, " ", "displaydata->begin_x", displaydata->begin_x)
        DEBUG_LOG_FLOAT     (DEBUG_THREADS, " ", "displaydata->begin_y", displaydata->begin_y)
        DEBUG_LOG_FLOAT     (DEBUG_THREADS, " ", "displaydata->dx", displaydata->dx)
        DEBUG_LOG_FLOAT     (DEBUG_THREADS, " ", "displaydata->dy", displaydata->dy)

        DEBUG_LOG_FLOAT     (DEBUG_THREADS, " ", "displaydata->frames_per_second", displaydata->frames_per_second)
 
  
/*
    GLuint gldisplay [GLDISPLAY_LISTS];

    gboolean animate;
     
    gfloat view_quat_diff [4];
    gfloat view_quat [4];
    gfloat view_scale;
    gfloat begin_x;
    gfloat begin_y; 
    gfloat dx;
    gfloat dy;
      
    GLfloat *sierpinski_color;

*/

/*
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->gltranslate [0]", scene->gltranslate [0])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->gltranslate [1]", scene->gltranslate [1])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->gltranslate [2]", scene->gltranslate [2])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->glrotate [0]", scene->glrotate [0])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->glrotate [1]", scene->glrotate [1])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->glrotate [2]", scene->glrotate [2])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->glrotate [3]", scene->glrotate [3])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "displaydata->sierpinski_color [0]", displaydata->sierpinski_color [0])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "displaydata->sierpinski_color [1]", displaydata->sierpinski_color [1])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "displaydata->sierpinski_color [2]", displaydata->sierpinski_color [2])
        DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "displaydata->sierpinski_color [3]", displaydata->sierpinski_color [3])
*/
  
        g_usleep (dbg_sleep);
        }
        else {
            LOG_INFO ("gthread_dbg terminated")
            return NULL;
        }
    }
}

 

/*
    GDK thread!!!!!!!
*/



/*
        GLXGEARS SOURCE!!!!!!!!!!!!!!!!!
*/


gpointer *gthread_move_scene (gpointer data) {

    #ifdef DEBUG_THREADS
        DEBUG_LOG_FLOW (DEBUG_THREADS, "scene demo movement thread attached. ", " ")
    #endif
  
    while (TRUE) {

        guint reference = 1; // 1 and higher means animation

        // in debug thread there shall be no #ifdef for logging - as debug thread may be attached or not
        if (gthreads->scene_demo_movement_runs) {

/*
            DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->glrotate [0]", scene->glrotate [0])
*/
/*
            scene->glrotate [0] = (GLfloat) scene->glrotate [0] + 2.0;
            if (scene->glrotate [0] > ANGLE_MAX)
                scene->glrotate [0] = ANGLE_MIN;
*/

/*
            DEBUG_LOG_FLOAT (DEBUG_THREADS, " ", "scene->glrotate [0]", scene->glrotate [0])

            cb_redisplay_gldisplay (reference);

            g_thread_yield ();
*/
    
/*
            redisplay_gldisplay ((gpointer) gl_area_main, (gpointer) displaydata, (gpointer) current);
*/
 
            g_usleep (move_sleep);
            reference++;
        }
        else {
            LOG_INFO ("gthread_move_scene terminated")
            return NULL;
        }
    }
}


