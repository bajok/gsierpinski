/*
 *      structures_gldisplay.h
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#ifndef __structures_gldisplay_h_
#define __structures_gldisplay_h_

#include <GL/gl.h>
#include <GL/glu.h>
#include "data_structures_init.h"
 
 


#define ANGLE_MAX  360.0
#define ANGLE_MIN -360.0

#define FIXED_Z   -4

 
#define gldisplay_MAX_LINE_COLORS 16


#define gldisplay_MAX_YDATA   2048
#define gldisplay_MAX_LAYERS  16


 
typedef enum {

    DISPLAY_DATA,
    DISPLAY_STATISTICS,
    DISPLAY_COMBINED,
  
} t_display_datatype_enum;

 

//~ --------------------------------------------------------------------------------------------------------------------
//~ *                                gldisplay_display_data
//~ --------------------------------------------------------------------------------------------------------------------
 
typedef struct _gldisplay_display_data gldisplay_display_data;

struct _gldisplay_display_data  {
 
    // this structure be explicitly initialized
    GLfloat Ydata [gldisplay_MAX_LAYERS][gldisplay_MAX_YDATA];       // graph highest point 
    // GLfloat Xmax  [gldisplay_MAX_LAYERS];
    GLfloat Xnum  [gldisplay_MAX_LAYERS];
    GLfloat color [gldisplay_MAX_LAYERS][4];
 
    // all display parameters (gldisplay required!) shall be stored here

 

  
}; 

 
//~ --------------------------------------------------------------------------------------------------------------------
//~ *                              gldisplay_properties
//~ --------------------------------------------------------------------------------------------------------------------

typedef struct _gldisplay_properties gldisplay_properties;

struct _gldisplay_properties  {

    GLfloat plane_thickness;
    GLfloat plane_altitude;
  
    GLfloat line_Z_layer;           // this should be line_Z [gldisplay_MAX_LAYERS]
    GLfloat line_thickness;
    GLfloat line_altitude;
    GLfloat line_color_R [gldisplay_MAX_LINE_COLORS];
    GLfloat line_color_G [gldisplay_MAX_LINE_COLORS];
    GLfloat line_color_B [gldisplay_MAX_LINE_COLORS];
    GLfloat line_color_A [gldisplay_MAX_LINE_COLORS];

};

//~ --------------------------------------------------------------------------------------------------------------------
//~ *                         gldisplay_scene
//~ --------------------------------------------------------------------------------------------------------------------

typedef struct _gldisplay_scene gldisplay_scene;

struct _gldisplay_scene {

    GLdouble dimensions [4];
    GLdouble Z_layer;

    // here may be also FIXED_Z

    GLdouble glupersp [4];

/*
    GLfloat aspect_x;
    GLfloat aspect_y;
*/

    GLfloat color [4];
    GLfloat clearcolor [4];
    GLfloat backgroundcolor [4];


    GLdouble gltranslate [3];
    GLdouble glrotate [4];


};
 

//~ --------------------------------------------------------------------------------------------------------------------
//~ *                              gldisplay_main_plane
//~ --------------------------------------------------------------------------------------------------------------------

typedef struct _gldisplay_main_plane gldisplay_main_plane;

struct _gldisplay_main_plane {

    GLdouble dimensions [4];
    GLdouble Z_layer;

    GLfloat  color [4];

    GLdouble glclearcolor [4];

};

/*
besides of that:

typedef struct _gldisplay_plane gldisplay_plane;
struct _gldisplay_plane {
}

typedef struct _gldisplay_rulers gldisplay_rulers;
struct _gldisplay_rulers {
}
*/
 
 

/*
int x;
x = x+1;
*/
 

void update_display_data (gldisplay_display_data *destination, 
                          current_data *source_params);

 

#endif // __structures_gldisplay_h_
