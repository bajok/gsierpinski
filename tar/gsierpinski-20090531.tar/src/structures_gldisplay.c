/*
 *      structures_gldisplay.c
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <GL/gl.h>
#include <GL/glu.h>
#include <gtk/gtkgl.h>
#include "data_structures_init.h"


  
  
//~ --------------------------------------------------------------------------------------------------------------------
//~ gldisplay_update_display_data
//~ --------------------------------------------------------------------------------------------------------------------


 
 // THIS should be a callback or a function called from a callback


// these functions write gldisplay_display_data struct




/*
static void displaydata_write_std_data (gldisplay_display_data *destination, std_entire_data *source,
                                        GLuint label_id, GLuint listing, GLuint range) {

    #ifdef DEBUG_GL
        DEBUG_LOG_FLOW      (DEBUG_GL, "displaydata_write_std_data", "writing display data")
    #endif 

    // ekhm -- range boundaries are determined at GUI level..
    for (guint iter = 0; (iter < gldisplay_MAX_YDATA) && (iter < range); iter++) {
 
        // switch data : V_OPEN, V_CLOSE....
 
        destination->Ydata [0][iter] = source->daily[listing+iter]->listed[label_id]->v_open;
        #ifdef DEBUG_GL
            DEBUG_LOG_FLOAT (DEBUG_GL, "displaydata_write_std_data", \
                                       "destination->Ydata [0][iter]", destination->Ydata [0][iter])
        #endif

    }


    destination->Xnum [0] = range;

}
*/

 
void gldisplay_update_display_data (gldisplay_display_data *destination,
                                    current_data *source_param) {

    #ifdef DEBUG_GL
        DEBUG_LOG_FLOW      (DEBUG_GL, "gldisplay_update_display_data", "updating display data")
    #endif 


/*
    displaydata_write_std_data (destination, data_source, label_id, listing, range);
*/



}



/*
                t_std_daily_result field_enum = 0;
                while (field_enum != (t_std_daily_result) VOLUME) {

gfloat get_std_value_by_l_ll  (guint label_id, guint listing, gint t_std_daily_result,
                               gint t_stock_enum, std_entire_data *source) {
*/
