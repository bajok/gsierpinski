/*
 *      gtk_callbacks.h
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#ifndef __gtk_callbacks_h_
#define __gtk_callbacks_h_


#include "gtk_frontend.h"
#include "gtk_frontend_gl_widgets.h"


#define ENUM_WIDGET_INDEX    GINT_TO_POINTER


 
typedef enum {

    PREDEFINED_COLOR_1,
    PREDEFINED_COLOR_2,
    PREDEFINED_COLOR_3,
    PREDEFINED_COLOR_4,
    
} t_cb_current_data;



typedef enum {
 
    SCENE_GLROTATE_ANGLE,
    SCENE_GLROTATE_X,
    SCENE_GLROTATE_Y,
    SCENE_GLROTATE_Z,
    SCENE_GLTRANSLATE_X,
    SCENE_GLTRANSLATE_Y,
    SCENE_GLTRANSLATE_Z,

    DATA_SIERP_COLOR_R,
    DATA_SIERP_COLOR_G,
    DATA_SIERP_COLOR_B,
    DATA_SIERP_COLOR_A,
    DATA_SIERP_DEPTH,

/*
    LINE_COLOR_R,
    LINE_COLOR_G,
    LINE_COLOR_B,
    LINE_COLOR_A,
*/

} t_cb_gldisplay_properties;


 

extern GdkGLConfig *glconfig;               // from gl_config.h

 

/*
void cb_chgval_sierp_gl_LookAt          (GtkAdjustment *adjustment, gpointer data);
*/


void cb_hide_widget_itself              (GtkWidget *widget, gpointer data);
void cb_toggle_widget_display_state     (GtkWidget* widget, gpointer data);
void cb_toggle_scene_demo_movement      (GtkWidget *widget, gpointer data);


void cb_app_close ();
void cb_null ();
gboolean widget_destroy                 (GtkWidget *widget);


//~ --------------------------------------------------------------------------------------------------------------------
//~ generic callback
//~ --------------------------------------------------------------------------------------------------------------------

void cb_chgval_current_data             (GtkWidget *spinbutton, gpointer data);
void cb_chgval_gldisplay_properties     (GtkWidget *spinbutton, gpointer data);
void cb_chgval_gldisplay_adjustment     (GtkAdjustment *adjustment, gpointer data);



/*
void cb_gldisplay_update_display_data (GtkWidget *widget, gpointer data);
*/




#endif // __gtk_callbacks_h
