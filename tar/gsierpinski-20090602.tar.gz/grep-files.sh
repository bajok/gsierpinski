#! /bin/bash

DIRECTORY="$1"
FILELIST=`ls $DIRECTORY`
GREP_PATTERN="$2"
GREP_SWITCHES=" $3"" $4"" $5"

PATH_AWK="awk"
awkgrepfile="$PATH_AWK""/grep-colorized.awk"

red="\033[0;31m"
green="\033[0;32m"
yellow="\033[0;33m"
blue="\033[0;34m"
magenta="\033[0;35m"
cyan="\033[0;36m"
white="\033[0;37m"
boldmagenta="\033[1;35m"

reset="\033[0;0;0m"

SEPARATOR="$green"" -- -- -- --""$reset""\n"
LONGSEPARATOR="$boldmagenta""........................................................................................................................""$reset""\n"

echo -ne "$LONGSEPARATOR"
echo -ne "$SEPARATOR"


for file in $FILELIST
# if file other than backup file...
#if [ "$file" 
do
  SEARCH_RESULT=`cat "$DIRECTORY"/"$file" | grep $GREP_SWITCHES -e $GREP_PATTERN`
  if [ -z "$SEARCH_RESULT" ]
  then
    echo -ne "                                                            \r"
  else
    echo -ne "  filename: ""$file"      | gawk -f $awkgrepfile
    echo -ne "$SEARCH_RESULT""\n" | gawk -f $awkgrepfile
    echo -ne "$SEPARATOR"
  fi
done

echo -ne "$LONGSEPARATOR"
