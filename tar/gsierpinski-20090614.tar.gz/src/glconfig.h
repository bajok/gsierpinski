#ifndef __glconfig_h_
#define __glconfig_h_

    // GdkGLConfig *glconfig;

    void configure_gtkglext ();
    //~ void print_gl_config_attrib (GdkGLConfig *glconfig, const gchar *attrib_str, int attrib, gboolean is_boolean);
    //~ void examine_gl_config_attrib (GdkGLConfig *glconfig);

#endif // __gl_config_h_
