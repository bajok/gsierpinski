#! /bin/bash

cd /home/ed/projects/gsierpinski/

COMMAND="/home/ed/projects/gsierpinski/remake.sh"
GEOMETRY=" --geometry=140x100+1100+140 "

EXECUTE=`echo -ne "gnome-terminal --command $COMMAND $GEOMETRY"`

echo $EXECUTE
$EXECUTE
