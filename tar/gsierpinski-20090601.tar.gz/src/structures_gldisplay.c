/*
 *      structures_gldisplay.c
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <GL/gl.h>
#include <GL/glu.h>
#include <gtk/gtkgl.h>
#include "data_structures_init.h"
 

  
  
//~ --------------------------------------------------------------------------------------------------------------------
//~ gldisplay_update_display_data
//~ --------------------------------------------------------------------------------------------------------------------


/*
static GLvoid copy_glcolor (GLfloat *destination_color, GLfloat *source_color) {

    for (GLuint iter = 0; iter < 4; iter++)
        destination_color [iter] = (GLfloat) source_color [iter];

}
*/
  
 
void gldisplay_update_display_data (gldisplay_display_data *destination,
                                    current_data *source_param) {

    #ifdef DEBUG_GL
        DEBUG_LOG_FLOW      (DEBUG_GL, "gldisplay_update_display_data", "updating display data")
    #endif 


    // conversions, checks, etc.


    #ifdef DEBUG_GL
        DEBUG_LOG_FLOW      (DEBUG_GL, "color copied", "color copied")
    #endif 

 
    // some other actions here....

}


