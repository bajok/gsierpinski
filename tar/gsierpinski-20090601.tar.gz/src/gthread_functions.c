/*
 *      gthread_functions.c
 *      
 *      Copyright 2009 Przemysław Dużyk <przemyslaw.duzyk@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <glib.h>
#include "data_structures_init.h"

 
//~ ----------------------------------------------------------------------------
//~ threads definitions and vars
//~ ----------------------------------------------------------------------------

gulong dbg_sleep = 60000 * 1000; // 60s

gpointer *gthread_dbg (gpointer data) {

    #ifdef DEBUG_THREADS
        LOG_INFO_VALUE ("debug thread attached. ", GPOINTER_TO_INT (data))
    #endif

    while (TRUE) {

        // in debug thread there shall be no #ifdef for logging - as debug thread may be attached or not
        DEBUG_LOG_FLOW (DEBUG_THREADS, "gthread_dbg", "dumping variable values:")
/*
        DEBUG_LOG_INTEGER (DEBUG_THREADS, " ", "config->graph_width",     config->graph_width)
        DEBUG_LOG_INTEGER (DEBUG_THREADS, " ", "config->graph_height",    config->graph_height)
        DEBUG_LOG_INTEGER (DEBUG_THREADS, " ", "current->get_listing",    current->get_listing)
        DEBUG_LOG_INTEGER (DEBUG_THREADS, " ", "current->get_label",      current->get_label)
*/

        g_usleep (dbg_sleep);
    }
}


 
